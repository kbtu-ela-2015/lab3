# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Intranet::Application.config.secret_token = '0381b44a25d02d60870995603eb456f96c8a7e58a84af24ed21988405153feec98e743d1a62790d77c0bc6264a5d89a734e1f0edb653b34450356d100132d625'
